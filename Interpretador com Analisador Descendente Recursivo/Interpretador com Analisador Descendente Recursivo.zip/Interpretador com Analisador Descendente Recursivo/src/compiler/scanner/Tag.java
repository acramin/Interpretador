package compiler.scanner;

public enum Tag { EOF, PLUS, MINUS, TIMES, 
    DIV, LPAREN, RPAREN, ID, NUMBER, MOD, EOL }

